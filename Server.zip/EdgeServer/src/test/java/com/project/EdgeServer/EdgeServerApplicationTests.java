package com.project.EdgeServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EdgeServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
