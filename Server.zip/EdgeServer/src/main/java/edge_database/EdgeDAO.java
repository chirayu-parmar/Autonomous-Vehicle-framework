package edge_database;

import edge.Edge;

public class EdgeDAO {
	private EdgeDatabase db;

	public EdgeDAO() {
		db = EdgeDatabase.getInstance();
	}
	
	public Edge getEdge(int edgeId) {
		switch (edgeId) {
		case 1:
			return db.edgeOne();
		case 2:
			return db.edgeTwo();
		case 3:
			return db.edgeThree();
		case 4:
			return db.edgeFour();
		case 5:
			return db.edgeFive();
		default:
			return null;
		}
	}
}
