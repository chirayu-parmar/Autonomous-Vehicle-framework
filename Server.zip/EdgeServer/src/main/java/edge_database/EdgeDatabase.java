package edge_database;

import edge.Edge;

public class EdgeDatabase {
	private static EdgeDatabase dbObject;
	private static Edge edgeOne;
	private static Edge edgeTwo;
	private static Edge edgeThree;
	private static Edge edgeFour;
	private static Edge edgeFive;

	private EdgeDatabase() {      
	}

	public static EdgeDatabase getInstance() {

		// create object if it's not already created
		if(dbObject == null) {
			dbObject = new EdgeDatabase();
			
			edgeOne = new Edge(18.0, 18.0);
			edgeTwo = new Edge(36.0, 36.0);
			edgeThree = new Edge(54.0, 54.0);
			edgeFour = new Edge(72.0, 72.0);
			edgeFive = new Edge(90.0, 90.0);
			
			edgeFive.addAdjacentEdge(edgeFour);
			
			edgeOne.addAdjacentEdge(edgeTwo);
			
			edgeTwo.addAdjacentEdge(edgeOne);
			edgeTwo.addAdjacentEdge(edgeThree);
			
			edgeThree.addAdjacentEdge(edgeTwo);
			edgeThree.addAdjacentEdge(edgeFour);
			
			edgeFour.addAdjacentEdge(edgeThree);
			edgeFour.addAdjacentEdge(edgeFive);
		}

		return dbObject;
	}
	
	public Edge edgeOne() {
		return edgeOne;
	} 
	
	public Edge edgeTwo() {
		return edgeTwo;
	} 
	
	public Edge edgeThree() {
		return edgeThree;
	} 
	
	public Edge edgeFour() {
		return edgeFour;
	} 
	
	public Edge edgeFive() {
		return edgeFive;
	} 
	
	
	public void getConnection() {
		System.out.println("You are now connected to the database.");
	}
}



