package edge;

public class DistanceCalculator {

	public double getDistance(double edgeLatitude,double edgeLongitude, double carLatitude, double carLongitude) {
		int earthRadius = 6371;
		
		edgeLatitude = Math.toRadians(edgeLatitude);
		edgeLongitude = Math.toRadians(edgeLongitude);
		carLatitude = Math.toRadians(carLatitude);
		carLongitude = Math.toRadians(carLongitude);

		// Haversine formula
		double dLon = carLongitude - edgeLongitude;
		double dLat = carLatitude - edgeLatitude;
		
		double a = Math.pow(Math.sin(dLat / 2), 2) + Math.pow(Math.sin(dLon / 2), 2) * 
                Math.cos(edgeLatitude) * 
                Math.cos(carLatitude);
		
		double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

		// Calculate the distance
		double distance = earthRadius * c;

		return distance;
	}
}
