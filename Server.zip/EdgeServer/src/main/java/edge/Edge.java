package edge;

import java.util.ArrayList;
import java.util.List;

public class Edge {
	private static int edgeID = 1;
	private List<String> cars;
	private int eID;
	private double latitude;
	private double longitude;
	private List<Edge> adjacentEdges;
	private DistanceCalculator calculator;

	public Edge(double latitude, double longitude) {
		this.latitude = latitude;
		this.longitude = longitude;

		this.setID();

		this.adjacentEdges = new ArrayList<Edge>();
		this.cars = new ArrayList<String>();

		this.calculator = new DistanceCalculator();
	}

	private void setID() {
		this.eID = edgeID;
		edgeID += 1;
	}

	public int getEdgeId() {
		return this.eID;
	}

	public double getLatitude() {
		return this.latitude;
	}

	public double getLongitude() {
		return this.longitude;
	}

	public void addAdjacentEdge(Edge edge) {
		this.adjacentEdges.add(edge);
	}

	public List<Edge> getAdjacentEdgeList() {
		return this.adjacentEdges;
	}

	public void connectCarToEdge(String carID) {
		this.cars.add(carID);
	}

	public void removeCarFromEdge(String carID) {
		this.cars.remove(carID);
	}

	public Edge findNearestEdge(String carID, double latitude, double longitude) {

		double carLatitude = longitude;
		double carLongitude = latitude;

		double edgeLatitude = this.latitude;
		double edgeLongitude = this.longitude;

		double closestDisatance = this.calculator.getDistance(edgeLatitude, edgeLongitude, carLatitude, carLongitude);
		Edge closestEdge = this;
		System.out.println("Latitude : " + carLatitude + " Longitude: " + carLongitude);
		System.out.println("Distance from current(" + this.eID + ") egde: " + closestDisatance);

		List<Edge> adjEdges = this.adjacentEdges;

		for (Edge edge : adjEdges) {

			edgeLatitude = edge.getLatitude();
			edgeLongitude = edge.getLongitude();

			double currentDisatance = this.calculator.getDistance(edgeLatitude, edgeLongitude, carLatitude,
					carLongitude);

			System.out.println("Adjacent edge distance(" + edge.eID + ") egde: " + currentDisatance);
			if (currentDisatance <= closestDisatance) {

				closestDisatance = currentDisatance;
				closestEdge = edge;
			}
		}

		// remove the car from current edge
		this.removeCarFromEdge(carID);
		
		// add the car to closest edge
		closestEdge.connectCarToEdge(carID);

		return closestEdge;
	}

	public String toString() {
		return "Edge " + this.eID;
	}
}
