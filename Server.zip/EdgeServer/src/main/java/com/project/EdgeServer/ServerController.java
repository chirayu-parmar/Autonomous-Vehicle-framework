package com.project.EdgeServer;
import java.util.*;

import org.json.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import edge.Edge;
import edge_database.EdgeDAO;

@RestController
public class ServerController {

	EdgeDAO edgeDAO = new EdgeDAO();
	Edge closestEdge = edgeDAO.getEdge(1);
	Edge tempEdge = edgeDAO.getEdge(1);
	Edge edge1 = edgeDAO.getEdge(1);
	Edge edge2 = edgeDAO.getEdge(2);
	Edge edge3 = edgeDAO.getEdge(3);
	Edge edge4 = edgeDAO.getEdge(4);
	Edge edge5 = edgeDAO.getEdge(5);
	// Handle POST request to receive data from the client
	@PostMapping("/server1")
	public String receiveDataFromClient1(@RequestBody String data) {
		// Do something with the received data, for example, print it

		//    	"{\"longitude\":"+longitude+",\"latitude\":"+latitude+",\"id\":"+car.carID+"}"
		JSONParser parser = new JSONParser();
		try {

			System.out.println("---------------------------------------");
			System.out.println(data);
			JSONObject json = (JSONObject) parser.parse(data);

			String carID = (String) json.get("id");
			Double longitude = Double.parseDouble((String) json.get("longitude"));
			Double latitude = Double.parseDouble((String) json.get("latitude"));

			System.out.println("carID: " + carID);
			System.out.println("longitude: " + longitude);
			System.out.println("latitude: " + latitude);

			tempEdge = closestEdge.findNearestEdge(carID, latitude, longitude);

			if(tempEdge.equals(edge1)) {
				closestEdge = tempEdge;
				System.out.println(data);
				return "Received data from the client: " + data;
			}

		} catch (ParseException e) {
			e.printStackTrace();
		}

		return null;
	}

	@PostMapping("/server2")
	public String receiveDataFromClient2(@RequestBody String data) {
		// Do something with the received data, for example, print it
		//    	"{\"longitude\":"+longitude+",\"latitude\":"+latitude+",\"id\":"+car.carID+"}"
		JSONParser parser = new JSONParser();
		try {

			System.out.println("---------------------------------------");
			System.out.println(data);
			JSONObject json = (JSONObject) parser.parse(data);

			String carID = (String) json.get("id");
			Double longitude = Double.parseDouble((String) json.get("longitude"));
			Double latitude = Double.parseDouble((String) json.get("latitude"));

			System.out.println("carID: " + carID);
			System.out.println("longitude: " + longitude);
			System.out.println("latitude: " + latitude);

			tempEdge = closestEdge.findNearestEdge(carID, latitude, longitude);

			if(tempEdge.equals(edge2)) {
				closestEdge = tempEdge;
				System.out.println(data);
				return "Received data from the client: " + data;
			}

		} catch (ParseException e) {
			e.printStackTrace();
		}

		return null;
	}

	@PostMapping("/server3")
	public String receiveDataFromClient3(@RequestBody String data) {
		// Do something with the received data, for example, print it
		//    	"{\"longitude\":"+longitude+",\"latitude\":"+latitude+",\"id\":"+car.carID+"}"
		JSONParser parser = new JSONParser();
		try {

			System.out.println("---------------------------------------");
			System.out.println(data);
			JSONObject json = (JSONObject) parser.parse(data);

			String carID = (String) json.get("id");
			Double longitude = Double.parseDouble((String) json.get("longitude"));
			Double latitude = Double.parseDouble((String) json.get("latitude"));

			System.out.println("carID: " + carID);
			System.out.println("longitude: " + longitude);
			System.out.println("latitude: " + latitude);

			tempEdge = closestEdge.findNearestEdge(carID, latitude, longitude);

			if(tempEdge.equals(edge3)) {
				closestEdge = tempEdge;
				System.out.println(data);
				return "Received data from the client: " + data;
			}

		} catch (ParseException e) {
			e.printStackTrace();
		}

		return null;
	}

	@PostMapping("/server4")
	public String receiveDataFromClient4(@RequestBody String data) {
		// Do something with the received data, for example, print it
		//    	"{\"longitude\":"+longitude+",\"latitude\":"+latitude+",\"id\":"+car.carID+"}"
		JSONParser parser = new JSONParser();
		try {

			System.out.println("---------------------------------------");
			System.out.println(data);
			JSONObject json = (JSONObject) parser.parse(data);

			String carID = (String) json.get("id");
			Double longitude = Double.parseDouble((String) json.get("longitude"));
			Double latitude = Double.parseDouble((String) json.get("latitude"));

			System.out.println("carID: " + carID);
			System.out.println("longitude: " + longitude);
			System.out.println("latitude: " + latitude);

			tempEdge = closestEdge.findNearestEdge(carID, latitude, longitude);

			if(tempEdge.equals(edge4)) {
				closestEdge = tempEdge;
				System.out.println(data);
				return "Received data from the client: " + data;
			}

		} catch (ParseException e) {
			e.printStackTrace();
		}

		return null;
	}

	@PostMapping("/server5")
	public String receiveDataFromClient5(@RequestBody String data) {
		// Do something with the received data, for example, print it
		//    	"{\"longitude\":"+longitude+",\"latitude\":"+latitude+",\"id\":"+car.carID+"}"
		JSONParser parser = new JSONParser();
		try {

			System.out.println("---------------------------------------");
			System.out.println(data);
			JSONObject json = (JSONObject) parser.parse(data);

			String carID = (String) json.get("id");
			Double longitude = Double.parseDouble((String) json.get("longitude"));
			Double latitude = Double.parseDouble((String) json.get("latitude"));

			System.out.println("carID: " + carID);
			System.out.println("longitude: " + longitude);
			System.out.println("latitude: " + latitude);

			tempEdge = closestEdge.findNearestEdge(carID, latitude, longitude);

			if(tempEdge.equals(edge5)) {
				closestEdge = tempEdge;
				System.out.println(data);
				return "Received data from the client: " + data;
			}

		} catch (ParseException e) {
			e.printStackTrace();
		}

		return null;
	}


	// Handle GET request (for your initial response)
	@GetMapping("/server")
	public String sendServerResponse() {
		List<String> serverList = new ArrayList<String>();     
		serverList.add("server" + closestEdge.getEdgeId());

		for(Edge edge : closestEdge.getAdjacentEdgeList()) {
			serverList.add("server" + edge.getEdgeId());
		}

		JSONArray ja = new JSONArray(serverList);

		System.out.println(ja.toString());
		return ja.toString();
	}
}
