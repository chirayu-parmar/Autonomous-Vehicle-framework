package data_strategy;

import com.project.Car.Website;

public class TrafficData implements SendStrategy {
    private OutlierDetector outlierDetector = new OutlierDetector();
    private Website website = new Website();

    @Override
    public void send(Object... data) {
    	  if (data != null && data.length > 0 && data[0] instanceof Double) {
    	
            double traffic = (double) data[0];
            outlierDetector.addReading(traffic); // Add the reading to the detector
            if (!outlierDetector.isOutlier(traffic)) { // Check if it's an outlier
                website.publicTrafficData(traffic);
            } else {
                System.out.println("Data not sent - outlier detected.");
            }
    	  }
       
    }
}


