package data_strategy;

import com.project.Car.Website;

public class TemperatureData implements SendStrategy {
    private OutlierDetector outlierDetector = new OutlierDetector();
    private Website website = new Website();

    @Override
    public void send(Object... data) {
        if (data != null && data.length > 0 && data[0] instanceof Double) {
            Double temperature = (Double) data[0];
            outlierDetector.addReading(temperature); // Add the reading to the detector
            if (!outlierDetector.isOutlier(temperature)) { // Check if it's an outlier
                website.publicTemperatureData(temperature);
            } else {
                System.out.println("Data not sent - outlier detected.");
            }
        }
    }
}



