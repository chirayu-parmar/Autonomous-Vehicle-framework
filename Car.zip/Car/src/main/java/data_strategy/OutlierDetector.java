package data_strategy;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Collections;

public class OutlierDetector {
    private Queue<Double> dataReadings = new LinkedList<>();
    private static final int MAX_READINGS = 5; // Number of readings to consider for calculating IQR

    public void addReading(Double data) {
        dataReadings.add(data);
        if (dataReadings.size() > MAX_READINGS) {
            dataReadings.poll(); // remove the oldest reading to maintain size
        }
    }

    public boolean isOutlier(Double data) {
        if (dataReadings.size() < MAX_READINGS) {
            // Not enough data to determine outliers
            return false; 
        }

        LinkedList<Double> sortedReadings = new LinkedList<>(dataReadings);
        Collections.sort(sortedReadings);

        int q1Index = sortedReadings.size() / 4;
        int q3Index = (sortedReadings.size() * 3) / 4;
        double q1 = sortedReadings.get(q1Index);
        double q3 = sortedReadings.get(q3Index);
        double iqr = q3 - q1;
        double lowerBound = q1 - 1.5 * iqr;
        double upperBound = q3 + 1.5 * iqr;

        return data < lowerBound || data > upperBound;
    }
}
