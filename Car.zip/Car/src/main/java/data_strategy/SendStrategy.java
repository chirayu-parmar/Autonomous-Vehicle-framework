package data_strategy;

public interface SendStrategy {
	
	public void send (Object... data);

}
