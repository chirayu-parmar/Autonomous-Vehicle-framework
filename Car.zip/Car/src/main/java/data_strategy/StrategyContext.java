package data_strategy;

public class StrategyContext {
	
	private SendStrategy sendStrategy;

	//set which strategy
	public StrategyContext(SendStrategy sendStrategy) {
		this.sendStrategy = sendStrategy;
	}
	
	//send the data
	public void executeStrategy (Object... data) {
	
        this.sendStrategy.send(data);
    }
}
