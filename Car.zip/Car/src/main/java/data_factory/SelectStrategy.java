package data_factory;

import data_strategy.StrategyContext;
import data_strategy.TemperatureData;
import data_strategy.TrafficData;

public class SelectStrategy {

	
	TemperatureData tempData;
	TrafficData trafficData;
	StrategyContext tempStrategyContext;
	StrategyContext trafficStrategyContext;
	
	public SelectStrategy() {
		this.tempData = new TemperatureData();
		this.trafficData = new TrafficData();
		this.tempStrategyContext = new StrategyContext(this.tempData);
		this.trafficStrategyContext = new StrategyContext(this.trafficData);
	}
	

	public void sendDataToWebsite(String typeOfData, Object... data) {
		switch (typeOfData) {
		//factory design to select which strategy is needed to be used based on data recieved
		case "Temperature":
			this.tempStrategyContext.executeStrategy(data);
			break;

		case "Traffic":
			
			this.trafficStrategyContext.executeStrategy(data);
			break;

		default:
			break;
		}
	}
}
