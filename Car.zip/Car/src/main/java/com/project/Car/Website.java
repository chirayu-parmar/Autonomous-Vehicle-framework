package com.project.Car;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/car")
public class Website {

	private static String temp;;
	private static String traffic;
	
	// api call for temp data
	@GetMapping("/temperature")
	public String temperatureAPI() {
		return temp;
	}
	
	// api- Temperature
	public void publicTemperatureData(Double temperature) {
		// consider as a JSON array
		//set the temp
		temp = "Temperature by car for public(every 3 seconds)(wb): " + temperature;
		System.out.println(temp + " ---");
		
	}
	
	//api call for traffic data
	@GetMapping("/traffic")
	public String trafficAPI() {
		return traffic;
	}
	
	// api - Traffic
	public void publicTrafficData(double trafficAmount) {
		// consider as a JSON array
		//set the temp
		traffic = "Traffic Level by car for public(every 3 seconds)(wb): " + trafficAmount;
		System.out.println(traffic + " ---");
	}	
}


