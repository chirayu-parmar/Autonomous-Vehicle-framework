package com.project.Car;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import car_mockup.Car;
import car_mockup.CoordinatesGenerator;


@SpringBootApplication
public class Part3Application {

	public static void main(String[] args) {

		// main class to represent running car
		SpringApplication.run(Part3Application.class, args);

		double latitude = 9.0;
		double longitude = 9.0;



		// car was parked at home or ideal stage
		Car car = new Car(latitude, longitude);

		long start = System.currentTimeMillis();

		while (true) {
			long end = System.currentTimeMillis();
			if (end - start >= 3000) {

				System.out.println("--------------------------------------------");

				CoordinatesGenerator cGenerator = new CoordinatesGenerator(car);
				latitude = cGenerator.generateRandomLatitude();
				longitude = cGenerator.generateRandomLongitude();

				// This is just beacuse latitude and longitude should not be more than 90.
				// https://www.nhc.noaa.gov/gccalc.shtml
				if (latitude >= 90)
					latitude = 0.0;
				if (longitude >= 90)
					longitude = 1.0;

				car.setLatitude(latitude);
				car.setLongitude(longitude);

				// send coordinate to server
				car.sendClientData("{\"longitude\":\""+longitude+"\",\"latitude\":\""+latitude+"\",\"id\":\""+car.carID+"\"}");
				car.getClientResponse();
				

				car.shareDataWithPublicWebsite();

				start = end;
			}
		}
	}

}
