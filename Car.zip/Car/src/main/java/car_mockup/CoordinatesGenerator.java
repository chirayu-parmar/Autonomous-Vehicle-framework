package car_mockup;

import java.util.Random;

public class CoordinatesGenerator {
	
	// mock data to create fake location of car
	
	private Car coordinate;
	private Random random;
	
	public CoordinatesGenerator(Car coordinate) {
		this.coordinate = coordinate;
		this.random = new Random();
	}
	
	private double generateRandomCoordinate() {
        return random.nextDouble() * 4.0; // Generates a random number between 0 and 4
    }
	
	public double generateRandomLatitude() {
        return this.coordinate.getLatitude() + generateRandomCoordinate(); // Adding to a base latitude of 40.0 for example
    }

    public double generateRandomLongitude() {
        return this.coordinate.getLongitude() + generateRandomCoordinate(); // Subtracting from a base longitude of -74.0 for example
    }
}
