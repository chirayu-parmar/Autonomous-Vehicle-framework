package car_mockup;

import java.util.ArrayList;

import org.json.JSONArray;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.client.RestTemplate;

import data_factory.SelectStrategy;
import public_website_adapter.SendTemperatureData;
import public_website_adapter.SendTrafficData;
import public_website_adapter.TemperatureDataAdapter;
import public_website_adapter.TrafficDataAdapter;

// car is exposing this API
// Immutable class
//mock up car object to represent real q car
public final class Car {
	// unique id of car
	public String carID = "car100";
	private double latitude;
	private double longitude;

	// private SelectStrategy selectStrategy;
	private TemperatureDataAdapter temperatureAdapter;
	private TrafficDataAdapter trafficDataAdapter;

	// mockup temp
	private double temp;
	private double trafficAmount;

	public Car(double latitude, double longitude) {
		this.latitude = latitude;
		this.longitude = longitude;

		this.temp = 20.0;
		this.trafficAmount = 50;

		this.temperatureAdapter = new SendTemperatureData();
		this.trafficDataAdapter = new SendTrafficData();
		// this.selectStrategy = new SelectStrategy();

	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public double getLatitude() {
		return latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setExtension(String extension) {
		this.URLExtension = extension;

	}

	private String URLExtension = "server1";
	private final RestTemplate restTemplate = new RestTemplate();

	// Change the URL if your server is running on a different port or host.
	String url = "https://4550b7bfd645e99c43d9f60e09cb3554.serveo.net/";
	ArrayList<String> serverList = new ArrayList<String>() {
		{
			add("server1");
			add("server2");

		}
	};

	public void getClientResponse() {
		serverList = new ArrayList<>();
		String jsonString = restTemplate.getForObject(url + "server", String.class);
		JSONArray obj = new JSONArray(jsonString);
		for (int i = 0; i < obj.length(); i++) {
			serverList.add(obj.getString(i));
		}

		System.out.println(jsonString);
	}

	public void sendClientData(@RequestBody String data) {

		for (String server : serverList) {
			setExtension(server);
			System.out.println(url + URLExtension);
			restTemplate.postForObject(url + URLExtension, data, String.class);

		}

	}

	// Data transmission
	public void shareDataWithPublicWebsite() {

		// select startegy for which data to sent to app
		this.temperatureAdapter.tempData(temp);
		this.trafficDataAdapter.trafficData(trafficAmount);


		// mock data from car

		this.temp += 0.5;
		this.trafficAmount += 5;

		if (temp == 28.0) {
			temp = 100;
		}

		if (temp == 100.5) {
			temp = 22;
		}

	}
}
