package public_website_adapter;

public interface TrafficDataAdapter {
	public void trafficData(double trafficAmount);
}





