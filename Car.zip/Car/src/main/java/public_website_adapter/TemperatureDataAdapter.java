package public_website_adapter;

public interface TemperatureDataAdapter {
	public void tempData(Double temperature);
}