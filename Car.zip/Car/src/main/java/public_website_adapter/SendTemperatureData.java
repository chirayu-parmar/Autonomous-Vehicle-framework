package public_website_adapter;

import data_factory.SelectStrategy;

public class SendTemperatureData implements TemperatureDataAdapter {
	SelectStrategy selectStratgey = new SelectStrategy();
	@Override
	//send data to website api acting as an adapter
	public void tempData(Double temperature) {
		selectStratgey.sendDataToWebsite("Temperature", temperature);
	}
}
