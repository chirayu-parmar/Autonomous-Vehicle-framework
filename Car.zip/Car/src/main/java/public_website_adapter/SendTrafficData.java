package public_website_adapter;

import data_factory.SelectStrategy;

public class SendTrafficData implements TrafficDataAdapter {
	SelectStrategy selectStrategy = new SelectStrategy();
	
	@Override
	//send data to website api acting as an adapter
	public void trafficData(double trafficAmount) {
	
		selectStrategy.sendDataToWebsite("Traffic", trafficAmount);
	}
}



